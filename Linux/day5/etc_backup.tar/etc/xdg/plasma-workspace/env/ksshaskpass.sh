SSH_ASKPASS=/usr/bin/ksshaskpass
export SSH_ASKPASS
